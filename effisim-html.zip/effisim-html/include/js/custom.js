jQuery(document).ready(function($) {



var list = $("ul.nsb-menu-list li.has-menu > i");

list.click(function (event) {
    var submenu = this.parentNode.getElementsByTagName("ul").item(0);
    //S'il existe un sous menu sinon c'est un lien terminal
    if(submenu!=null){
        event.preventDefault();
        $(submenu).slideToggle();
        $(this).toggleClass('active');
    }
});

   var $range = $(".js-range-slider"),
         $input = $(".js-input"),
         instance,
         min = 0,
         max = 1000;

        $range.ionRangeSlider({
         skin: "square",
         type: "single",
         min: min,
         max: max,
         from: 100,
         onStart: function(data) {
             $input.prop("value", data.from);
         },
         onChange: function(data) {
             $input.prop("value", data.from);
         }
        });

        instance = $range.data("ionRangeSlider");

        $input.on("change keyup", function() {
         var val = $(this).prop("value");

         validate
         if (val < min) {
             val = min;
         } else if (val > max) {
             val = max;
         }

         instance.update({
             from: val
         });
     });



$( ".sort-btn,.home-overlay" ).click(function() {     
   $('body').toggleClass('show-sortby-box'), 1000;
});

$( ".add-button-outer" ).click(function() {     
   $(this).toggleClass('open');
   $(this).parent().find('.pll-text-box').toggleClass('active-list');
   $(this).parent().find('.pll-img-box').toggleClass('active-list');
});


$(".md-search-icon,.new-search-row .close").click(function() {
  $('body').toggleClass('search-open');
});

 $(".table-wrap").each(function() {
   var nmtTable = $(this);
   var nmtHeadRow = nmtTable.find("thead tr");
   nmtTable.find("tbody tr").each(function() {
     var curRow = $(this);
     for (var i = 0; i < curRow.find("td").length; i++) {
       var rowSelector = "td:eq(" + i + ")";
       var headSelector = "th:eq(" + i + ")";
       curRow.find(rowSelector).attr('data-title', nmtHeadRow.find(headSelector).text());
     }
   });
 });
 // Change button text 
  $('.viewmore-button[data-toggle="collapse"]').click(function() {
  $(this).toggleClass( "active" );
  if ($(this).hasClass("active")) {
    $(this).text("Show less Categories");
  } else {
    $(this).text("Show all Categories");
  }
});

 
if($('.mobile-slider').length > 0){
jQuery('.mobile-slider').slick({
  slidesToShow: 1,
  slidesToScroll: 1,
  dots: true,
  arrows: false, 
  infinite: true, 
  centerMode: false, 
  responsive: [
    {
      breakpoint: 5000,
      settings: "unslick"
    },
    {
      breakpoint: 768,
      settings: {
        arrows: false,
        slidesToShow: 1,
        slidesToScroll: 1,
        dots: true,  
        adaptiveHeight: false
      }
    }
  ]
});
}
 
$('.product-gridview-slider').slick({
  dots:false,
  infinite: false,
  speed: 300,
  slidesToShow: 4,
  slidesToScroll: 1,
  responsive: [
    {
      breakpoint: 1800,
      settings: {
        dots:false,
        slidesToShow: 4,
        slidesToScroll: 1
      }
    }
    ,
    {
      breakpoint: 1024,
      settings: {
        dots:false,
        slidesToShow: 2,
        slidesToScroll: 1
      }
    },
    {
      breakpoint: 700,
      settings: {
        dots:false,
        slidesToShow: 2,
        slidesToScroll: 1
      }
    },
    {
      breakpoint: 579,
      settings: {
        dots:false,
        arrows:false,
        slidesToShow: 1,
        slidesToScroll: 1
      }
    }
  ]
});


if($('.hpc-product-slider').length > 0){
jQuery('.hpc-product-slider').slick({
    dots: true,
    infinite: false,
    speed: 300,
    slidesToShow: 4,
    slidesToScroll: 1,
    prevArrow: jQuery('.prev'),
     nextArrow: jQuery('.next'),
     responsive: [
        {
          breakpoint: 991,
          settings: { 
            slidesToShow: 3,
            slidesToScroll: 1,
            dots:false
          }
        },
        {
          breakpoint: 579,
          settings: { 
            slidesToShow: 2,
            slidesToScroll: 1,
            dots:false
          }
        }
      ]
  });
}


$('[data-toggle="popover"]').popover({
  html: true,
  content: function() {
    var id = $(this).attr('id')
    return $('#po' + id).html();
  }
});

$("#siderMenu").click(function() {
  $('body').toggleClass('open-sider-menu');
  $('.overlay').addClass('show');
});
$(".close-menu").click(function() {
  $('body').toggleClass('open-sider-menu');
  $('.overlay').removeClass('show');
});

$(".sidebar_toggler").click(function() {
  $("#" + $(this).attr("data-toggle")).addClass('show');
  $('.overlay').addClass('show');
});
$(".close").click(function() {
  $(".tab-modify-slidebar,.tab-slidebar").removeClass('show');
  $('.overlay').removeClass('show');
});

$('.table-responsive').on('show.bs.dropdown', function () {
     $('.table-responsive').css( "overflow", "visible" );
});

$('.table-responsive').on('hide.bs.dropdown', function () {
     $('.table-responsive').css( "overflow", "auto" );
});

$('.close-icon').click(function() {
  $(this).parents('.dropdown').find('button.dropdown-toggle').dropdown('toggle')
});


$('.table-dropdown .dropdown-toggle').on('click', function() {
  $('body').toggleClass('show-menu'); 
     
  });


  $('.overlay,.close-icon').on('click', function() {
  $('body').removeClass('show-menu'); 
     
  });

$('.table-dropdown .dropdown-menu').click(function(event){
    event.stopPropagation();
  });


  $(function () {
        $('[data-toggle="tooltip"]').tooltip()
    })
 


$('.nav-icon').on('click', function() {
  $('body').toggleClass('show-menu'); 
     
  });


  $('.overlay').on('click', function() {
  $('body').removeClass('show-menu'); 
     
  });

      
$(".toggle-password,.toggle-password2").click(function() {

  $(this).toggleClass('toggle');

  var input = $($(this).attr("toggle"));
  if (input.attr("type") == "password") {
      input.attr("type", "text");
  } else {
      input.attr("type", "password");
  }
});

/*******************************product modify start***************************************/
$('.physicalVisit').click(function(){
  $("body").toggleClass('toggled-tab');
});
$('.close').click(function(){
  $("body").removeClass('toggled-tab');
});
/******************************product modify end****************************************/

$("html").click(function() {
    $(".custom-dropdown").removeClass('show');
});

$('.custom-dropdown-outer > div > a').on('click', function() {
    if ($(this).parent().find('.custom-dropdown').hasClass('show')) {
        $('.custom-dropdown').removeClass('show');
    } else {
        $('.custom-dropdown').removeClass('show');
        $(this).next().addClass('show');
    }
  return false;

});

$('.custom-dropdown').click(function(event) {
    event.stopPropagation();
});


/*==========================*/
/* Header fix */
/*==========================*/
var scroll = $(window).scrollTop();
if (scroll >= 10) {
    $("body").addClass("fixed");
} else {
    $("body").removeClass("fixed");
}

});



$(window).scroll(function() {
    var scroll = $(window).scrollTop();
    if (scroll >= 10) {
        $("body").addClass("fixed");
    } else {
        $("body").removeClass("fixed");
    }
});