
jQuery(document).ready(function($){


$('#list-tabs').waypoint(function(direction) {
  $('#scrollspy-list').toggleClass('tabs-fixed');
},{ 
  offset: '100'
});

$('#list-tabs > li > a').click(function(){
    var id = $(this).attr('href');
    $(id).slideDown();
    $('html, body').animate({scrollTop: $(id).offset().top - 120}, 300);
    return false;
});
 

$('.close-dropdown-icon').click(function() {
  $(this).parents('.dropdown').find('.dropdown-toggle').dropdown('toggle')
});

// Global Avoid dropdown menu close on click inside.
$(document).on('click', '.avoid-auto-close-outside .dropdown-menu', function (e) {
   e.stopPropagation();
 });

// Notification Toggler 
const $menu = $('.notify-dropdrown-menu');
  $(document).mouseup(e =>{
      if (!$menu.is(e.target) 
       && $menu.has(e.target).length === 0){$menu.removeClass('is-active');
    }
  }
);

$('.dropdown-toggle-icon').on('click',() =>
  {
    $menu.toggleClass('is-active');
  }
);



$("#viewMoreBtn").click(function(){
  $('#benefitsList li').removeClass("hide");  
  $('#viewMoreBtn').addClass("d-none");
});


$('#editBasicInfo').click(function(){
      $('.profile-status-block').show()
  })

  $('.close-basic-info').click(function(){
      $('.profile-status-block').hide()
  })  

/*==========================*/  
/* Countdown */ 
/*==========================*/

 $(".clock").countdown('2022/12/01', function(event) {
    $(this).html(event.strftime('<span>%D <b>days</b></span> <span>%H<b>hrs</b></span> <span>%M<b>mins</b></span> <span>%S<b>sec</b></span>'));
  });

$("#togglemenu,.sidebar-menu-head .navbar-toggler").click(function(){
  $('body').toggleClass("open-sidebar");
});

$("#mainMenu").click(function(){
  $('body').toggleClass("menu-open");  
});


 // PREVENT INSIDE MEGA DROPDOWN
 $('.custom-dropdown .dropdown-menu,.admin-dropdown .dropdown-menu').on("click.bs.dropdown", function (e) {
     e.stopPropagation();
     e.preventDefault();                
 });


$(".custom-dropdown .dropdown-toggle").click(function () {
     $('body').toggleClass('modal-open');
 });

  $('.overlay, #closeDropdown').on('click', function(e) {
    if ($('body').hasClass('modal-open')) {
       $('body').removeClass('modal-open')
    }
 });
 $('#closeDropdown').on('click', function(e) {
    $('.custom-dropdown .dropdown-menu').removeClass('show')
 });

// Show Hide DIV with TextBox based on RadioButton selection (checked unchecked).
$("input[name$='haveMentor']").click(function() {
     var test = $(this).val();
     $(".desc").hide();
     $("#haveMentor" + test).show();
 });

// Change button text 
$('.viewmore-btn[data-toggle="collapse"]').click(function() {
  $(this).toggleClass( "active" );
  if ($(this).hasClass("active")) {
    $(this).text("View less");
  } else {
    $(this).text("View more");
  }
});

// Change button text2 
$('.viewmore-button[data-toggle="collapse"]').click(function() {
  $(this).toggleClass( "active" );
  if ($(this).hasClass("active")) {
    $(this).text("View more");
  } else {
    $(this).text("View less");
  }
});


$('body').on('click', function (e) {
  $('[data-toggle=popover]').each(function () {
      // hide any open popovers when the anywhere else in the body is clicked
      if (!$(this).is(e.target) && $(this).has(e.target).length === 0 && $('.popover').has(e.target).length === 0) {
          $(this).popover('hide');
      }
  });
});


$(".popover-block-container button[data-toggle=popover]").popover({
    html : true,
    trigger: 'focus',
    content: function() {
        var content = $(this).attr("data-popover-content");
        return $(content).children(".popover-body").html();
    }
});

// Tooltip init
$('[data-toggle="popover"]').popover();  

// $(".menu-close-icon").click(function() {

//   $('.navbar-toggler').addClass('collapsed');
//   $('.navbar-collapse').removeClass('show');
// }

// password hide and show
$(".toggle-password").click(function() {

  $(this).toggleClass('toggle');

  var input = $($(this).attr("toggle"));
  if (input.attr("type") == "password") {
      input.attr("type", "text");
  } else {
      input.attr("type", "password");
  }
});
// nice select init
$('select:not(.ignore)').niceSelect();



/*==========================*/  
/* Mobile Slider */  
/*==========================*/ 
if($('.profile-nav-slider').length > 0){
jQuery('.profile-nav-slider').slick({
  dots: false,
  arrows: true, 
  infinite:false, 
  responsive: [
    {
      breakpoint: 5000,
      settings: "unslick"
    },
    {
      breakpoint: 991,
      settings: {
        slidesToShow: 8,
        slidesToScroll: 1,
        variableWidth: true
      }
    },
    {
      breakpoint: 767,
      settings: {
        slidesToShow: 6,
        slidesToScroll: 1,
        variableWidth: true
      }
    },
    {
      breakpoint: 550,
      settings: {
        slidesToShow: 4,
        slidesToScroll: 1,
        variableWidth: true
      }
    },
    {
      breakpoint: 400,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 1,
        variableWidth: true
      }
    }
  ]
});
}


/*==========================*/ 
/* sliders */ 
/*==========================*/
if($('.card-block-slider').length > 0){
  jQuery('.card-block-slider').slick({
    slidesToShow: 1,
    slidesToScroll: 1,
    dots: false,
    arrows: false, 
    infinite: true, 
    fade:true,
    adaptiveHeight:true,
    centerMode: false,
    autoplay: true,
    autoplaySpeed: 2000,
     
  });
}

if($('.image-slider').length > 0){
  jQuery('.image-slider').slick({
    slidesToShow: 1,
    slidesToScroll: 1,
    dots: false,
    arrows: true, 
    adaptiveHeight:true,
    infinite: true, 
    centerMode: false,
    autoplay:false,
    autoplaySpeed: 2000,
    adaptiveHeight:true,
     
  });
}

 $('.sgl-text-slider').slick({
  slidesToShow: 1,
  slidesToScroll: 1,
  arrows: false,
  adaptiveHeight:true,
  infinite:false,
  adaptiveHeight:true,
  asNavFor: '.sgb-slider'
});
$('.sgb-slider').slick({
  slidesToShow: 1,
  slidesToScroll: 1,
  asNavFor: '.sgl-text-slider',
  adaptiveHeight:true,
  infinite:false,
  adaptiveHeight:true,
  prevArrow: $('.prev'),
     nextArrow: $('.next')
});

 /* ==============================================================================================*/
 /*==========================*/ 
/* smart goals slider for new Dashboard page */ 
/*==========================*/


$('.thumbnail-slider').slick({
  slidesToShow: 1,
  slidesToScroll: 1,
  arrows: false,
  draggable:false,
  // fade: true,
  adaptiveHeight:true,
  asNavFor: '.text-slick-slider'
});


var helpers = {
    addZeros: function (n) {
        return (n < 10) ? '0' + n : '' + n;
    }
};

function sliderInit1() {
  var $slider = $('.text-slick-slider');
  $slider.each(function() {
    var $sliderParent = $(this).parent();
    $(this).slick({
      slidesToShow: 1,
  slidesToScroll: 1,
  asNavFor: '.thumbnail-slider',
  infinite:false,
  adaptiveHeight:true,
  draggable:false,
  prevArrow: $('.prev'),
  nextArrow: $('.next')
      
    });

    if ($(this).find('.wsb-slider-item').length > 1) {
      $('.custom-paginator-slick').siblings('.slides-numbers.new').show();
    }

    $(this).on('afterChange', function(event, slick, currentSlide){
      $('.custom-paginator-outer').find('.slides-numbers.new .active').html(helpers.addZeros(currentSlide + 1));
    });

    var sliderItemsNum = $(this).find('.slick-slide').not('.slick-cloned').length;
    $('.custom-paginator-outer').find('.slides-numbers.new .total').html(helpers.addZeros(sliderItemsNum));

  });

};

sliderInit1();



 /*==========================*/ 
/* smart goals slider for new Dashboard page  Past Mentorships */ 
/*==========================*/
var helpers = {
    addZeros: function (n) {
        return (n < 10) ? '0' + n : '' + n;
    }
};

function sliderInit() {
  var $slider = $('.new-past-membership-slider');
  $slider.each(function() {
    var $sliderParent = $(this).parent();
    $(this).slick({
      slidesToShow: 1,
  slidesToScroll: 1,
  dots:false,
  arrows: true, 
  infinite:false, 
   fade: true,
  centerMode: false, 
   prevArrow: $('.prev1'),
  nextArrow: $('.next1')
      
    });

    if ($(this).find('.npwidget-slider-item').length > 1) {
      $(this).siblings('.slides-numbers.first').show();
    }

    $(this).on('afterChange', function(event, slick, currentSlide){
      $('.custom-paginator-outer').find('.slides-numbers.first .active').html(helpers.addZeros(currentSlide + 1));
    });

    var sliderItemsNum = $(this).find('.slick-slide').not('.slick-cloned').length;
    $('.custom-paginator-outer').find('.slides-numbers.first .total').html(helpers.addZeros(sliderItemsNum));

  });

};

sliderInit();







 


/*==========================*/ 
/* smart goals slider for new Profile page */ 
/*==========================*/
var $status = $('.slider-counter');
var $slickElement = $('.fwb-text-slider');

$slickElement.on('init reInit afterChange', function(event, slick, currentSlide, nextSlide){
    var i = (currentSlide ? currentSlide : 0) + 1;
    $status.text
    $status.text('0' + i + '/' + '0' + slick.slideCount);
});

$slickElement.slick({
  slidesToShow: 1,
  slidesToScroll: 1,
  infinite:false,
  dots: false,
  draggable:false,
  adaptiveHeight:true,
  prevArrow: $('.prev'),
  nextArrow: $('.next'),
  focusOnSelect: true
});



// var $status = $('.slider-counter');
var $slickElement = $('.past-mentorship-slider');
// $slickElement.on('init reInit afterChange', function(event, slick, currentSlide, nextSlide){
//     var i = (currentSlide ? currentSlide : 0) + 1;
//     $status.text
//     $status.text('0' + i + '/' + '0' + slick.slideCount);
// });
$slickElement.slick({
  slidesToShow: 1,
  slidesToScroll: 1,  
  infinite:false,
  dots: false,
  draggable:false,
  adaptiveHeight:true,
  prevArrow: $('.prev1'),
  nextArrow: $('.next1'),
  focusOnSelect: true
});





$('#viewmoreAward').click(function () {
      $('#awardDatalist li:hidden').slice(0, 2).show();
      if ($('#awardDatalist li').length == $('#awardDatalist li:visible').length) {
          $('#viewmoreAward').hide();
      }
  });

$('#viewmore').click(function () {
      $('#experienceDatalist li:hidden').slice(0, 2).show();
      if ($('#experienceDatalist li').length == $('#experienceDatalist li:visible').length) {
          $('#viewmore').hide();
      }
  });
$('#eduViewmore').click(function () {
      $('#eduDatalist li:hidden').slice(0, 2).show();
      if ($('#eduDatalist li').length == $('#eduDatalist li:visible').length) {
          $('#eduViewmore').hide();
      }
  });

$('#coreskillmore').click(function () {
      $('#coreskillTags li:hidden').slice(0, 4).show();
      if ($('#coreskillTags li').length == $('#coreskillTags li:visible').length) {
          $('#coreskillmore').hide();
      }
  });

$('#moreProjects').click(function () {
      $('#newProjectData li:hidden').slice(0, 3).show();
      if ($('#newProjectData li').length == $('#newProjectData li:visible').length) {
          $('#moreProjects').hide();
      }
  });

$('#moreEvents').click(function () {
      $('#eventsData li:hidden').slice(0, 3).show();
      if ($('#eventsData li').length == $('#eventsData li:visible').length) {
          $('#moreEvents').hide();
      }
  });

 /* ==============================================================================================*/

/*==========================*/  
/* Change Text on Collapse div */  
/*==========================*/
$('.btn-expand').click(function () {
   $(this).text(function (i, old) {
      return old == 'View More' ? 'View Less' : 'View More';
   });
 });

/*==========================*/  
/* Mobile Slider */  
/*==========================*/ 
if($('.mobile-slider').length > 0){
jQuery('.mobile-slider').slick({
  slidesToShow: 1,
  slidesToScroll: 1,
  dots: true,
  arrows: false, 
  infinite: true, 
  centerMode: false, 
  responsive: [
    {
      breakpoint: 5000,
      settings: "unslick"
    },
    {
      breakpoint: 768,
      settings: {
        arrows: false,
        slidesToShow: 1,
        slidesToScroll: 1,
        dots: true,  
        adaptiveHeight: false
      }
    }
  ]
});
}
 

/*==========================*/  
  /* Event Listing Slider */  
/*==========================*/ 

 $('.banner-text-slider').slick({
    slidesToShow: 1,
    slidesToScroll: 1,
    arrows: false,
    fade: true,
    autoplay:true,
    asNavFor: '.banner-image-slider'
  });
  $('.banner-image-slider').slick({
    slidesToShow: 1,
    slidesToScroll: 1,
    asNavFor: '.banner-text-slider',
    arrows: false,
    dots: true,
    autoplay:true,
    focusOnSelect: true
  });

 

/*==========================*/  
/* Scroll on animate */  
/*==========================*/
function onScrollInit( items, trigger ) {
  items.each( function() {
    var osElement = $(this),
        osAnimationClass = osElement.attr('data-os-animation'),
        osAnimationDelay = osElement.attr('data-os-animation-delay');
        osElement.css({
          '-webkit-animation-delay':  osAnimationDelay,
          '-moz-animation-delay':     osAnimationDelay,
          'animation-delay':          osAnimationDelay
        });
        var osTrigger = ( trigger ) ? trigger : osElement;
        osTrigger.waypoint(function() {
          osElement.addClass('animated').addClass(osAnimationClass);
          },{
              triggerOnce: true,
              offset: '95%',
        });
// osElement.removeClass('fadeInUp');
  });
}
onScrollInit( $('.os-animation') );
onScrollInit( $('.staggered-animation'), $('.staggered-animation-container'));


/*==========================*/
/* Header fix */
/*==========================*/
var scroll = $(window).scrollTop();
if (scroll >= 10) {
    $("body").addClass("fixed");
} else {
    $("body").removeClass("fixed");
}


});


$(window).scroll(function() {
    var scroll = $(window).scrollTop();
    if (scroll >= 10) {
        $("body").addClass("fixed");
    } else {
        $("body").removeClass("fixed");
    }
});






