jQuery(document).ready(function($){

//   $('#selectedFile').change(function () {
//     var a = $('#selectedFile').val().toString().split('\\');
//     $('#tempInput').val(a[a.length -1]);
// });

  // $("#datepicker").datepicker({ 
   
  //       autoclose: true, 
  //       todayHighlight: true,
  // }).datepicker();

/*==========================*/  
/*DatePicker */ 
/*==========================*/
$('.datepicker').pickadate({
  weekdaysShort: ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'],
  showMonthsShort: true,
  disable: [1], 
  min: true,
  max: +14,
  clear: ''
})
  /*==========================*/  
/*TimePicker */ 
/*==========================*/
$('.timepicker').pickatime({
  clear: '',
  min: [10,0],
  max: [20,0],
  
  
}) 

  $('.gallery-slider').slick({
              dots: false,
              infinite: true,         
              slidesToShow: 4,
              slidesToScroll: 1,
              arrows: true,
              autoplay: true,
              autoplaySpeed: 1000,
              speed: 200,
              responsive: [
    {
      breakpoint: 1200,
      settings: {
        slidesToShow: 3,
        slidesToScroll: 1
      }
    },
    {
      breakpoint: 992,
      settings: {
        arrows: true,
        slidesToShow: 2,
        slidesToScroll: 1,
      }
    },
    {
      breakpoint: 768,
      settings: {
        arrows: true,
        slidesToShow: 2,
        slidesToScroll: 1,
      }
    },
    {
      breakpoint: 550,
      settings: {
        arrows: true,
        slidesToShow: 1,
        slidesToScroll: 1,
      }
    }
  ] 
        });


      $('.testimonial-slider').slick({
        dots: true,
        infinite: true,
        speed: 500,
        slidesToShow: 3,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 2000,
        arrows: true,
        responsive: [{
          breakpoint: 600,
          settings: {
            slidesToShow: 2,
            slidesToScroll: 1,
          }
        },
        {
           breakpoint: 991,
           settings: {
              arrows: false,
              slidesToShow: 1,
              slidesToScroll: 1
           }
        },
        {
           breakpoint: 600,
           settings: {
              arrows: false,
              slidesToShow: 1,
              slidesToScroll: 1
           }
        }
        ]
    });


});

   
 
