'use strict'
/*=====================================================================*/
document.getElementById('navbarSideCollapse').onclick = function() {
    document.getElementsByTagName('body')[0].classList.add("menu-open");
}
document.getElementById('close').onclick = function() {
    document.getElementsByTagName('body')[0].classList.remove("menu-open");
}
document.getElementById('overlay').onclick = function() {
    document.getElementsByTagName('body')[0].classList.remove("menu-open");
}
/*=====================================================================*/
window.onscroll = function() {
    myFunction()
};
var body = document.getElementsByTagName("body")[0];
var sticky = body.offsetTop + 50;

function myFunction() {
    if (window.pageYOffset > sticky) {
        body.classList.add("fixed");
    } else {
        body.classList.remove("fixed");
    }
}
/*=====================================================================*/
var swiper = new Swiper(".mySwiper", {
    effect: "fade",
    autoHeight: true,
    navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev",
    },
    // autoplay: {

    //     delay: 2500,
    //     disableOnInteraction: false,

    // },
    loop: true,
//     pagination: {

//         el: ".swiper-pagination",
//         clickable: true,
// },

    // mousewheel: true,
    keyboard: true,
});




var swiper = new Swiper(".five-column-slider", {
         slidesPerView: 5,
         spaceBetween: 30,
         // centeredSlides: true,
         // loop: true,
          breakpoints: {
           
            320: {
                spaceBetween: 10,
              slidesPerView: 2
            
            },
            640: {
                spaceBetween: 10,
              slidesPerView: 3
    
            },
            991: {
              slidesPerView: 4
             
            },
            1024: {
              slidesPerView: 5
             
            }
          },
         navigation: {
          nextEl: ".swiper-button-next2",
          prevEl: ".swiper-button-prev2",
        },
        
    });
/*=====================================================================*/
// Toggle Div When select option will selected!
function showDiv(divId, element)
 {
    // if (divId) {}

     document.getElementById(divId).style.display = element.value == 2 ? 'block' : 'none';
 }

 
var swiper = new Swiper(".gallery-slider", {

        loop: true,
        navigation: {
        nextEl: ".swiper-prev",
        prevEl: ".swiper-next",
    },
});


var swiper = new Swiper(".pmb-slide", {
    loop: true,
    navigation: {
    nextEl: ".swiper-button-next",
    prevEl: ".swiper-button-prev",
    },
});


document.getElementById('wrapper').onclick = function() {

    var className = ' ' + wrapper.className + ' ';

    this.className = ~className.indexOf(' active ') ?
        className.replace(' active ', ' ') :
        this.className + ' active';
};

// Show/Hide password through javascript
function showPwd(id, el) {
    let x = document.getElementById(id);
    if (x.type === "password") {
        x.type = "text";
        el.src = "include/images/eye-off.svg";
    } else {
        x.type = "password";
        el.src = "include/images/eye.svg";
    }
}



// ======================================================
gsap.registerPlugin(ScrollTrigger);

ScrollTrigger.matchMedia({

    // desktop
    "(min-width: 768px)": function() {
        const animateProcess = gsap.utils.toArray(".animate-child");
        animateProcess.forEach((title) => {
            gsap.to(title, {
                scrollTrigger: {
                    trigger: title,
                    once: true,
                    start: 'top 90%',
                    toggleClass: 'animated',
                }
            })
        });
    },

    // mobile
    "(max-width: 767px)": function() {
        const animateProcess = gsap.utils.toArray(".animate-child");
        animateProcess.forEach((title) => {
            gsap.to(title, {
                scrollTrigger: {
                    trigger: title,
                    once: true,
                    start: 'top 100%',
                    toggleClass: 'animated',
                }
            })
        });
    }

});
// 




ScrollTrigger.matchMedia({

    // desktop
    "(min-width: 768px)": function() {
        const animateProcess = gsap.utils.toArray(".animate-child2");
        animateProcess.forEach((title) => {
            gsap.to(title, {
                scrollTrigger: {
                    trigger: title,
                    once: true,
                    start: 'top 90%',
                    toggleClass: 'animated',
                }
            })
        });
    },

    // mobile
    "(max-width: 767px)": function() {
        const animateProcess = gsap.utils.toArray(".animate-child2");
        animateProcess.forEach((title) => {
            gsap.to(title, {
                scrollTrigger: {
                    trigger: title,
                    once: true,
                    start: 'top 100%',
                    toggleClass: 'animated',
                }
            })
        });
    }

});
// 

ScrollTrigger.matchMedia({

    // desktop
    "(min-width: 768px)": function() {
        gsap.utils.toArray(".main-text").forEach(cb => {
            var tl = gsap.timeline({
                scrollTrigger: {
                    trigger: cb,
                    start: "top bottom",
                    scrub: true
                }
            });
            tl.to(cb, {
                y: 25,
            });
        });

        gsap.utils.toArray(".sub-text").forEach(cb => {
            var tl = gsap.timeline({
                scrollTrigger: {
                    trigger: cb,
                    start: "top bottom",
                    scrub: true
                }
            });
            tl.to(cb, {
                y: -20,
            });
        });
    },

    // mobile
    "(max-width: 767px)": function() {
        gsap.utils.toArray(".main-text").forEach(cb => {
            var tl = gsap.timeline({
                scrollTrigger: {
                    trigger: cb,
                    start: "top 50%",
                    scrub: true
                }
            });
            tl.to(cb, {
                y: 25,
            });
        });

        gsap.utils.toArray(".sub-text").forEach(cb => {
            var tl = gsap.timeline({
                scrollTrigger: {
                    trigger: cb,
                    start: "top 50%",
                    scrub: true
                }
            });
            tl.to(cb, {
                y: -20,
            });
        });
    }

});



ScrollTrigger.matchMedia({

    // desktop
    "(min-width: 768px)": function() {
        gsap.utils.toArray(".box1").forEach(cb => {
            var tl = gsap.timeline({
                scrollTrigger: {
                    trigger: cb,
                    start: "top bottom",
                    scrub: true
                }
            });
            tl.to(cb, {
                y: -54,
            });
        });
    },

    // mobile
    "(max-width: 767px)": function() {
        gsap.utils.toArray(".box1").forEach(cb => {
            var tl = gsap.timeline({
                scrollTrigger: {
                    trigger: cb,
                    start: "top bottom",
                    scrub: true
                    // markers:true
                }
            });
            tl.to(cb, {
                y: -54,
            });
        });
    }

});

ScrollTrigger.matchMedia({

    // desktop
    "(min-width: 768px)": function() {
        gsap.utils.toArray(".box2").forEach(cb => {
            var tl = gsap.timeline({
                scrollTrigger: {
                    trigger: cb,
                    start: "top bottom",
                    scrub: true
                    // markers:true
                }
            });
            tl.to(cb, {
                y: 58,
            });
        });
    },

    // mobile
    "(max-width: 767px)": function() {
        gsap.utils.toArray(".box2").forEach(cb => {
            var tl = gsap.timeline({
                scrollTrigger: {
                    trigger: cb,
                    start: "top bottom",
                    scrub: true
                    // markers:true
                }
            });
            tl.to(cb, {
                y: 58,
            });
        });
    }

});




gsap.utils.toArray('.animate-circle').forEach(animateCircle => {

    gsap.to(animateCircle, { 
     scrollTrigger: {
        trigger: animateCircle, 
        start: 'top 80%', 
        once: true,
        toggleClass:'animated', 
        //markers:true,
        }
        
    });

});


