'use strict'
/*=====================================================================*/


// =================================================================

function increaseValue() {
    var value = parseInt(document.getElementById('number').value);
    value = isNaN(value) ? 0 : value;
    value++;
    document.getElementById('number').value = value;
}
function decreaseValue() {
    var value = parseInt(document.getElementById('number').value);
    value = isNaN(value) ? 0 : value;
    value < 1 ? value = 1 : '';
    value--;
    document.getElementById('number').value = value;
}

function increaseValue1() {
    var value = parseInt(document.getElementById('number1').value);
    value = isNaN(value) ? 0 : value;
    value++;
    document.getElementById('number1').value = value;
}
function decreaseValue1() {
    var value = parseInt(document.getElementById('number1').value);
    value = isNaN(value) ? 0 : value;
    value < 1 ? value = 1 : '';
    value--;
    document.getElementById('number1').value = value;
}

function increaseValue2() {
    var value = parseInt(document.getElementById('number2').value);
    value = isNaN(value) ? 0 : value;
    value++;
    document.getElementById('number2').value = value;
}
function decreaseValue2() {
    var value = parseInt(document.getElementById('number2').value);
    value = isNaN(value) ? 0 : value;
    value < 1 ? value = 1 : '';
    value--;
    document.getElementById('number2').value = value;
}



/*=====================================================================*/
/*=====================================================================*/
var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
  return new bootstrap.Tooltip(tooltipTriggerEl)
})
/*=====================================================================*/
/*=====================================================================*/
window.onscroll = function() {
    myFunction()
};
var body = document.getElementsByTagName("body")[0];
var sticky = body.offsetTop + 50;

function myFunction() {
    if (window.pageYOffset > sticky) {
        body.classList.add("fixed");
    } else {
        body.classList.remove("fixed");
    }
}
/*=====================================================================*/
gsap.registerPlugin(ScrollTrigger);

ScrollTrigger.matchMedia({

    // desktop
    "(min-width: 768px)": function() {
        const animateProcess = gsap.utils.toArray(".animate-child");
        animateProcess.forEach((title) => {
            gsap.to(title, {
                scrollTrigger: {
                    trigger: title,
                    once: true,
                    start: 'top 90%',
                    toggleClass: 'animated',
                }
            })
        });
    },

    // mobile
    "(max-width: 767px)": function() {
        const animateProcess = gsap.utils.toArray(".animate-child");
        animateProcess.forEach((title) => {
            gsap.to(title, {
                scrollTrigger: {
                    trigger: title,
                    once: true,
                    start: 'top 100%',
                    toggleClass: 'animated',
                }
            })
        });
    }

});
/*=====================================================================*/

function oneTimePurchase(){
  document.getElementById('subscribePannel').style.display ='none';
}
function subscribeAndSave(){
  document.getElementById('subscribePannel').style.display = 'block';
}




var $ = jQuery.noConflict();

jQuery(document).ready(function($){

    $('.product-slider-list').slick({
      slidesToShow: 1,
      slidesToScroll: 1,
      arrows: false,
      infinite: true,
      asNavFor: '.product-nav-list'
    });
    $('.product-nav-list').slick({
      slidesToShow: 4,
      slidesToScroll: 1,
      asNavFor: '.product-slider-list',
      dots: false,
      arrows: true,
      infinite: true,
      responsive: [
        {
          breakpoint: 575,
          settings: {
            slidesToShow: 3,
            arrows: true,
          }
        }
      ]
    });

    $('.mobile-slider').slick({
      slidesToShow: 2,
      slidesToScroll: 1,
      dots: true,
      arrows: false, 
      infinite: true,  
      responsive: [
        {
          breakpoint: 5000,
          settings: "unslick"
        },
        {
          breakpoint: 768,
          settings: {
            arrows: false,
            dots: true,  
            adaptiveHeight: true
          }
        },{
          breakpoint: 579,
          settings: {
            arrows: false,
            slidesToShow: 1,
            slidesToScroll: 1,
            dots: true,  
            adaptiveHeight: true
          }
        }

      ]
    });

});