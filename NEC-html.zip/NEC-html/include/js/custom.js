'use strict';

function toggleMenu() {
  var el = document.getElementsByClassName("nav-icon");
  var element = document.getElementsByTagName("body")[0];
  for (var f = 0; f < el.length; f++) {
    var elit = el[f];
    element.classList.toggle('show-menu');
    element.classList.toggle('overflow-hidden');

  }

}

window.onscroll = function() {
    myFunction()
};
var body = document.getElementsByTagName("body")[0];
var sticky = body.offsetTop + 50;

function myFunction() {
    if (window.pageYOffset > sticky) {
        body.classList.add("fixed");
    } else {
        body.classList.remove("fixed");
    }
}

const links = document.querySelectorAll(".navbar-nav li a");

for (const link of links) {
  link.addEventListener("click", clickHandler);
}

function clickHandler(e) {
  e.preventDefault();
  const element = document.getElementsByTagName("body")[0];
    element.classList.remove('show-menu');
    element.classList.remove('overflow-hidden');
  const href = this.getAttribute("href");
  const offsetTop = document.querySelector(href).offsetTop;

  scroll({
    top: offsetTop,
    behavior: "smooth"
  }), 800;
}




gsap.registerPlugin(ScrollTrigger);

 

   
let heroTl = gsap.timeline()
heroTl.to(".hero-imge-area", { opacity: 1, scale: 1, duration: 0.6,  delay: 1,  ease: "power2.inOut" })
.to(".create", {y:'0%', duration:0.4, stagger:0.2,delay: 0}, "-=0.3")
.to(".hero-container p", {opacity: 1, duration:0.5, delay: 0}, "-=0.2")
.to(".hero-btn", {opacity: 1, duration:0.5, delay: 0}, "-=0.2")





const tl = gsap.timeline({
  scrollTrigger: {
    trigger: ".media-row-container",
    start:"top top",
    end:"bottom top",
    scrub: true
  }
});




gsap.to("picture img", {rotation: 360, transformOrigin: "center", ease: "none", duration: 60, repeat: -1});



  
ScrollTrigger.matchMedia({
  
  // desktop
  "(min-width: 768px)": function() {
gsap.utils.toArray('.is-parallax').forEach(paraitem => {
    gsap.to(paraitem, {y:-100, ease: 'none',
        scrollTrigger: {
        trigger: paraitem, 
        start: 'top bottom',
        scrub: true,
        //markers:true,
        }
    });

});


}

});



var $ = jQuery.noConflict();

jQuery(document).ready(function ($) {


$(".custom-slider.slider-one").slick({
  asNavFor: '.custom-slider.slider-two,.custom-slider.slider-three',
  slidesToShow: 3,
  arrows:false,
  dots:false,
  swipe:false,
  infinite:true,
  speed: 6000,
  autoplay: true,
  autoplaySpeed: 0,
  cssEase: 'linear',
  draggable:false,
  accessibility: false,
  responsive: [
    {
      breakpoint: 768,
      settings: {
        slidesToShow: 2,
      }
    }
  ]
    
});
$('.custom-slider.slider-two').slick({  
  asNavFor: '.custom-slider.slider-one,.custom-slider.slider-three',
  slidesToShow: 3,
  arrows:false,
  dots:false,
  swipe:false,
  infinite:true,
  speed: 5000,
  autoplay: true,
  autoplaySpeed: 0,
  cssEase: 'linear',
  draggable:false,
  rtl: true,
  accessibility: false,
  responsive: [
    {
      breakpoint: 768,
      settings: {
        slidesToShow: 2,
      }
    }   
  ]
});

$('.custom-slider.slider-three').slick({
  rtl: false,
  asNavFor: '.custom-slider.slider-one,.custom-slider.slider-two',
  slidesToShow: 3,
  arrows:false,
  dots:false,
  swipe:false,
  infinite:true,
  speed: 6000,
  autoplay: true,
  autoplaySpeed: 0,
  cssEase: 'linear',
  draggable:false,
  accessibility: false,
   responsive: [
    {
      breakpoint: 768,
      settings: {
        slidesToShow: 2,
      }
    }
  ]
});



$('.post-slider').slick({
  slidesToShow: 1,
  slidesToScroll: 1,
  dots: true,
  arrows: false, 
  infinite: true, 
  centerMode: false, 
  responsive: [
    {
      breakpoint: 5000,
      settings: "unslick"
    },
    {
      breakpoint: 768,
      settings: {
        arrows: false,
        slidesToShow: 1,
        slidesToScroll: 1,
        dots: true,
        adaptiveHeight: true
      }
    }
  ]
});



  var $wrapperSlider = $('.wrapper-slider'),
    wrapperSlider = $wrapperSlider[0];
  $('.wrapper-slider').slick({
    dots: false,
    arrows: true,
    variableWidth: false,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
    swipe: true,
    responsive: [
    
    {
      breakpoint:768,
      settings: {
        arrows:true
      }
    },
    {
      breakpoint: 480,
      settings: {
       arrows:true
      }
    }
  ]
  });

  $('.wrapper-inner-slider').on('mousedown', function () {
    wrapperSlider.slick.setOption({
      swipe: false
    })
  })

  $('.wrapper-inner-slider').slick({
      dots: true,
      infinite: false,
      centerMode: false,
      variableWidth: false,
      arrows:false,
      fade:true,
      speed: 500,
      slidesToShow: 1,
      slidesToScroll: 1,
      swipe: true,
      responsive: [
    
    {
      breakpoint:768,
      settings: {
        dots: true,
        arrows:false
      }
    },
    {
      breakpoint: 480,
      settings: {
       dots:true,
       arrows:false
      }
    }
  ]
    }).on('afterChange', function (event, slick) {
      wrapperSlider.slick.setOption({
        swipe: true
      })
    });



// /*==========================*/
// /* Scroll on animate */
// /*==========================*/
// function onScrollInit(items, trigger) {
//     items.each(function() {
//         var osElement = $(this),
//             osAnimationClass = osElement.attr('data-os-animation'),
//             osAnimationDelay = osElement.attr('data-os-animation-delay');
//         osElement.css({
//             '-webkit-animation-delay': osAnimationDelay,
//             '-moz-animation-delay': osAnimationDelay,
//             'animation-delay': osAnimationDelay
//         });
//         var osTrigger = (trigger) ? trigger : osElement;
//         osTrigger.waypoint(function() {
//             osElement.addClass('animated').addClass(osAnimationClass);
//         }, {
//             triggerOnce: true,
//             offset: '95%',
//         });
//         // osElement.removeClass('fadeInUp');
//     });
// }
// onScrollInit($('.os-animation'));
// onScrollInit($('.staggered-animation'), $('.staggered-animation-container'));


});